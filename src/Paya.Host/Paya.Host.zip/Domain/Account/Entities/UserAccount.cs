﻿namespace Paya.Host.Domain.Account.Entities
{
    public class UserAccount : BaseEntity
    {
        public int UserId { get; set; }
        public decimal Balance { get; set; }
        public decimal ReservedAmount { get; set; }
        public string ShebaNumber { get; set; }
        public DateTime UpdateAt { get; set; }
    }
}
